export { default as Home } from "./home/Home";
export { default as Profile } from "./profile/Profile";
export { default as Cart } from "./cart/Cart";
export { default as Favourite } from "./favourite/Favourite";
export { default as DetailProduct } from "./detail_product/DetailProduct";