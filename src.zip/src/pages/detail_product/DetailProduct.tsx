import React from 'react';
import { useParams } from "react-router-dom";
import { useGetProductQuery } from '@store/apiRTK/apiRTK';

const DetailProduct: React.FC = () => {

  const { id } = useParams();

  const { data, isError, isLoading } = useGetProductQuery(id!)

  return (
    <section className="section-app">
      <div className="container">
        {
          isLoading ?
            <h1>Loading...</h1>
            : isError ?
              <h1>Error</h1>
              : data ?
                <div className='flex'>
                  <div className='flex-1 border-2'>

                  </div>
                  <div className='flex-1'></div>
                </div>
                : <h1>No Data</h1>
        }
      </div>
    </section>
  )
}

export default DetailProduct