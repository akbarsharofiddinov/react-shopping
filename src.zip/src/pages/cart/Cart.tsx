import React from 'react'

const Cart: React.FC = () => {
  return (
    <div>Cart</div>
  )
}

export default Cart