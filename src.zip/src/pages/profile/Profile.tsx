import React from "react";

const Profile: React.FC = () => {
  return (
    <section className="section-app">
      <div className="container">
        <h1>Profile</h1>
      </div>
    </section>
  );
};

export default Profile;