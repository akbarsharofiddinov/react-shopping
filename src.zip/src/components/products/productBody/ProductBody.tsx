import React from "react";
import { useGetProductsQuery } from "@store/apiRTK/apiRTK";
import { useAppSelector } from "@store/hooks/redux-Hook";
import ProductItem from "./productItem/ProductItem";
import LoadingProducts from "./loadingProducts/LoadingProducts";

const ProductBody: React.FC = () => {
  const { searchQuery } = useAppSelector((state) => state.searchQuerySlice);
  const {
    data: products,
    isLoading,
    isError,
  } = useGetProductsQuery(searchQuery);

  return (
    <section className="section-app">
      {isError ?
        <div>
          <h1>Error</h1>
        </div> : isLoading ? (
          <LoadingProducts />
        ) : (
          <div className="grid grid-cols-4 gap-[20px]">
            {products?.length ? products?.map((product) => (
              <ProductItem key={product.id} data={product} />
            )) : <>No Data</>}
          </div>
        )}
    </section>
  );
};

export default ProductBody;
